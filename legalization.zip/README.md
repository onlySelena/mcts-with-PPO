# Pin Legalizer 

本文档面向对接数据源的需求，说明 `run_pin_legalizer.py` / `pin_legalizer.py` 的输入输出格式、关键字段及注意事项。
# 功能概览

`run_pin_legalizer.py` 会读取布局模块信息与 pin 网表（通过`PlaceDB.py`处理过的`block.json`和`pingroup.json`），再读取初始 pin 坐标（`result.json`），在模块边界上进行约束优化与合法化，输出合法化后的坐标。
# 运行入口

- 主入口：`run_pin_legalizer.py`
- 核心算法：`pin_legalizer.py`
# 工作目录

·`block.json`
·`pingroup.json`
·`PlaceDB.py`
·`result.json`
·`run_pin_legalizer.py`
·`pin_legalizer.py`
# 输入文件

## 1) `block.json`

## 2) `pingroup.json`

## 3) `result.json`

# 输出文件

`result_legalized.json`
结构与 `result.json` 一致。